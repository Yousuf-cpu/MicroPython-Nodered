from machine import Pin,SoftI2C
import ssd1306
import dht    
import time
from time import sleep
 
i2c = SoftI2C(scl=Pin(22), sda=Pin(21))
led = Pin(12, Pin.OUT)
led0 = Pin(14, Pin.OUT)
push_button = Pin(34, Pin.IN)

oled=ssd1306.SSD1306_I2C(128,64,i2c) 

d=dht.DHT11(Pin(18))

initial = 0      
oldstate = 0       
buttonstate = 0
 
while True:
  time.sleep(1)
  d.measure()       
  t=d.temperature() 
  h=d.humidity()    
  print('Temperature=', t, 'C', 'Humidity=', h, '%')


  logic_state = push_button.value()
  if logic_state == True:
    initial = oldstate + 1
    if logic_state == False:
      sleep(0.2)
    else:
      sleep(0.2)

  else:                       # if push_button not pressed
      led.value(0) 

  if initial == 1:
    oled.fill(0)
    oled.text('Yousaf Siddiqui',0,0)
    oled.show()
    oldstate =  initial
    
    
  elif initial == 2:
    oled.fill(0)
    oled.text("Temperature",20,10)
    oled.text(str(t),40,20)
    oled.text("Deg C", 60,20)
    oled.show()
    oldstate =  initial

  elif initial == 3:
    oled.fill(0)
    oled.text("Humidity",20,10)
    oled.text(str(h),40,20)
    oled.text("%", 60,20)
    oled.show()
    oldstate =  0 

    
  



      

    


  